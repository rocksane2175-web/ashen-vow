ASHEN VOW — Cathedral Edition
------------------------------

Bu klasör statik web sitesi olarak yayınlanmaya hazırdır.

Yayınlama:
1. Vercel hesabınızı bağlayın.
2. Bu klasörü veya ZIP içeriğini bir GitHub deposuna yükleyin.
3. Vercel'de New Project > Import Git Repository adımlarını izleyin.
4. Framework Preset: Other, Build Command: boş, Output Directory: . seçin.
5. Deploy düğmesine basın.

Not: Oyun tek bir index.html dosyasıdır. İlerleme ve ganimet envanteri,
oyuncunun tarayıcısında localStorage ile saklanır.
